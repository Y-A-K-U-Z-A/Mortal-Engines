import core.MachineFactoryImpl;
import core.MachinesManagerImpl;

import core.PilotFactoryImpl;
import core.interfaces.MachineFactory;
import core.interfaces.PilotFactory;
import core.interfaces.MachinesManager;
import entities.PilotImpl;
import entities.TankImpl;
import entities.interfaces.Machine;
import entities.interfaces.Pilot;
import entities.interfaces.Tank;


import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        PilotFactory pilotFactory = new PilotFactoryImpl(); //TODO change null with your implementation
        MachineFactory machineFactory = new MachineFactoryImpl(); //TODO change null with your implementation
        Map<String, Pilot> pilots = new LinkedHashMap<>();
        Map<String, Machine> machines = new LinkedHashMap<>();

        MachinesManager machinesManager = new MachinesManagerImpl(pilotFactory, machineFactory, pilots, machines);

        String line = sc.nextLine();
        while (!line.equals("Over")){

            String[] tokens = line.split("\\s+");
            String name = tokens[1];
            //•	ManufactureTank {tankName} {attackPoints} {DefensePoints}
            //•	ManufactureFighter {fighterName} {attackPoints} {DefensePoints}
            //•	Engage {pilotName} {machineName}
            //•	Attack {attackingMachineName} {defendingMachineName}
            //•	DefenseMode {machineName}
            //•	AggressiveMode {machineName
            try {
            switch (tokens[0]) {
                case "Hire":
                    System.out.println(machinesManager.hirePilot(name));
                    pilots.putIfAbsent(name, pilotFactory.createPilot(name));
                    break;
                case "Report":
                    System.out.print(machinesManager.pilotReport(name));
                    break;
                case "ManufactureTank":
                    System.out.println(machinesManager.manufactureTank(name, Double.parseDouble(tokens[2]), Double.parseDouble(tokens[3])));
                    machines.put(name,machineFactory.createTank(name, Double.parseDouble(tokens[2]), Double.parseDouble(tokens[3])));
                    break;
                case "ManufactureFighter":
                    System.out.println(machinesManager.manufactureFighter(name, Double.parseDouble(tokens[2]), Double.parseDouble(tokens[3])));
                   machines.put(name, machineFactory.createFighter(name,  Double.parseDouble(tokens[2]), Double.parseDouble(tokens[3])));
                    break;
                case "Engage":
                    Machine machine = machines.get(tokens[2]);
                    System.out.println(machinesManager.engageMachine(name, tokens[2]));
                    break;
                case "Attack":
                    System.out.println(machinesManager.attackMachines(name, tokens[2]));
                    break;
                case "DefenseMode":
                    System.out.println(machinesManager.toggleTankDefenseMode(name));
                    break;
                case "AggressiveMode":
                    System.out.println(machinesManager.toggleFighterAggressiveMode(name));
                    break;
            }

            }
            catch (Exception e){
                System.out.println("Machine " + name + " does not support this operation");
            }

            line = sc.nextLine();
        }

    }
}
