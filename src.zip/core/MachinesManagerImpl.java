package core;

import common.OutputMessages;
import core.interfaces.MachineFactory;
import core.interfaces.PilotFactory;
import core.interfaces.MachinesManager;

import entities.BaseMachine;
import entities.PilotImpl;
import entities.interfaces.Fighter;
import entities.interfaces.Machine;
import entities.interfaces.Pilot;
import entities.interfaces.Tank;

import java.util.Map;

public class MachinesManagerImpl implements MachinesManager {
private PilotFactory pilotFactory;
private MachineFactory machineFactory;
private Map<String, Pilot> pilots;
private Map<String, Machine> machines;

    public MachinesManagerImpl(PilotFactory pilotFactory, MachineFactory machineFactory, Map<String, Pilot> pilots, Map<String, Machine> machines) {
            this.pilotFactory = pilotFactory;
            this.machineFactory = machineFactory;
            this.pilots = pilots;
            this.machines = machines;
    }


    @Override
    public String hirePilot(String name) {
        if (pilots.containsKey(name)){
            return String.format(OutputMessages.pilotExists, name);
        }
        Pilot pilot = this.pilotFactory.createPilot(name);
        this.pilots.putIfAbsent(name, pilot);
        return String.format(OutputMessages.pilotHired, name);
    }

    @Override
    public String manufactureTank(String name, double attackPoints, double defensePoints) {
        if (machineIsAlreadyManufactured(name)){
            return String.format(OutputMessages.machineExists, name);
        }
        Tank tank = this.machineFactory.createTank(name, attackPoints, defensePoints);
        this.machines.putIfAbsent(name, tank);
        return String.format(OutputMessages.tankManufactured, name, attackPoints, defensePoints);
    }


    @Override
    public String manufactureFighter(String name, double attackPoints, double defensePoints) {
        if (machineIsAlreadyManufactured(name)){
            return String.format(OutputMessages.machineExists, name);
        }
        Fighter fighter = this.machineFactory.createFighter(name, attackPoints, defensePoints);
        this.machines.putIfAbsent(name, fighter);
        return String.format(OutputMessages.fighterManufactured, name, attackPoints, defensePoints);
    }

    @Override
    public String engageMachine(String selectedPilotName, String selectedMachineName) {
        Pilot pilot =  pilots.get(selectedPilotName);
        Machine machine = machines.get(selectedMachineName);

            if (!findMachine(selectedMachineName)){
                return String.format(OutputMessages.machineNotFound, selectedMachineName);
            }else if (!findPilot(selectedPilotName)){
                return String.format(OutputMessages.pilotNotFound, selectedPilotName);
            }else if (!findMachine(selectedMachineName) && !findPilot(selectedPilotName)){
                String line = String.format(OutputMessages.pilotNotFound, selectedPilotName)
                        + System.lineSeparator() +String.format(OutputMessages.machineNotFound, selectedMachineName) ;
                return line;
            }

        if (machine.getPilot() == null){
            pilot.addMachine(machine);
            machine.setPilot(pilot);
            return String.format(OutputMessages.machineEngaged,selectedPilotName,  selectedMachineName);
        }else {
            return String.format(OutputMessages.machineHasPilotAlready, selectedMachineName);
        }
    }

    @Override
    public String attackMachines(String attackingMachineName, String defendingMachineName) {
        if (!findMachine(attackingMachineName) && !findMachine(defendingMachineName)){
            return String.format(OutputMessages.machineNotFound, attackingMachineName) + System.lineSeparator()+String.format(OutputMessages.machineNotFound, defendingMachineName);
        }
        else if (!findMachine(attackingMachineName)){
            return String.format(OutputMessages.machineNotFound, attackingMachineName);
        }else if (!findMachine(defendingMachineName)){
            return String.format(OutputMessages.machineNotFound, defendingMachineName);
        }

        Machine attacker = machines.get(attackingMachineName);
        Machine defender = machines.get(defendingMachineName);
        attacker.attack(defendingMachineName);
        if (attacker.getAttackPoints() > defender.getDefensePoints()){
            defender.setHealthPoints(defender.getHealthPoints() - attacker.getAttackPoints());
            if (defender.getHealthPoints() < 0){
                defender.setHealthPoints(0);
            }
        }
        return String.format(OutputMessages.attackSuccessful,defendingMachineName, attackingMachineName, defender.getHealthPoints());
    }

    @Override
    public String pilotReport(String pilotName) {
        if (findPilot(pilotName)){
            return pilots.get(pilotName).report();
        }else{
            return String.format(OutputMessages.pilotNotFound, pilotName)+System.lineSeparator();
        }
    }

    @Override
    public String toggleFighterAggressiveMode(String fighterName) {
        if (findMachine(fighterName)){
            Fighter machine = (Fighter) machines.get(fighterName);
            machine.toggleAggressiveMode();
            return String.format(OutputMessages.fighterOperationSuccessful, fighterName);
        }else {
            return String.format(OutputMessages.machineNotFound,fighterName);
        }
    }

    @Override
    public String toggleTankDefenseMode(String tankName) {
        if (findMachine(tankName)){
            Tank machine = (Tank) machines.get(tankName);
            machine.toggleDefenseMode();
            return String.format(OutputMessages.tankOperationSuccessful, tankName);
        }else {
            return String.format(OutputMessages.machineNotFound,tankName);
        }
    }


    private boolean machineIsAlreadyManufactured(String name) {
        for (String s : machines.keySet()) {
            if (s.equals(name)){
                return true;
            }
        }
        return false;
    }

    private boolean findPilot(String pilotName) {
        return pilots.containsKey(pilotName);
    }
    private boolean findMachine(String machineName){
        return machines.containsKey(machineName);
    }
}
