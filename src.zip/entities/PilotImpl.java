package entities;

import entities.interfaces.Machine;
import entities.interfaces.Pilot;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

public class PilotImpl implements Pilot {
    private String name;
    private Collection<Machine> machines;

    public PilotImpl(String name) {
        this.setName(name);
        machines = new ArrayList<>();
    }

    private void setName(String name) {
        if (name == null || name.trim().isEmpty()){
            throw new IllegalArgumentException("Pilot name cannot be null or empty string.");
        }
        this.name = name;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void addMachine(Machine machine) {
        if (machine == null ){
            throw new NullPointerException("Null machine cannot be added to the pilot.");
        }
        this.machines.add(machine);
    }

    @Override
    public List<Machine> getMachines() {
        return this.machines.stream().collect(Collectors.toList());
    }

    @Override
    public String report() {
        StringBuilder sb = new StringBuilder();
        if (machines.isEmpty()){
            sb.append(String.format("%s - 0 machines", this.name)).append(System.lineSeparator());
            return sb.toString();
        }
        sb.append(String.format("%s - %d machines", this.name, this.getMachines().size()));
        sb.append(System.lineSeparator());

            for (Machine machine : machines) {
                sb.append("- ").append(machine.getName());
                sb.append(System.lineSeparator()).append(machine.toString());
            }


        return sb.toString();
    }
}
