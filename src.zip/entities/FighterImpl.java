package entities;

import entities.interfaces.Fighter;

import java.util.ArrayList;

public class FighterImpl extends BaseMachine implements Fighter {
    private boolean aggressiveMode;
    private static double attackPointsModifier = 50;
    private static double defensePointsModifier = 25;
    public FighterImpl(String name, double attackPoints, double defensePoints) {
        super(name, attackPoints, defensePoints, 200);
        aggressiveMode = false;
        toggleAggressiveMode();
    }

    @Override
    public boolean getAggressiveMode() {
        return aggressiveMode;
    }

    @Override
    public void toggleAggressiveMode() {
        if (aggressiveMode){
            // true ---> false
            setAttackPoints(getAttackPoints()-attackPointsModifier);
            setDefensePoints(getDefensePoints()+defensePointsModifier);
            aggressiveMode = false;
        }else {
            //false ----> true
            setAttackPoints(getAttackPoints()+attackPointsModifier);
            setDefensePoints(getDefensePoints()-defensePointsModifier);
            aggressiveMode = true;
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        if (getTargets().isEmpty()){
            sb.append("None");
        }else {
            ArrayList<String> arr = new ArrayList<>(getTargets());
            for (int i = 0; i < arr.size(); i++) {
                if (i == arr.size() -1){
                    sb.append(arr.get(i));
                }else {
                    sb.append(arr.get(i)).append(", ");
                }
            }
        }
        String mode = "";

        if (getAggressiveMode()){
            mode= "ON";
        }else {
            mode = "OFF";
        }
        return String.format(" *Type: Fighter%n *Health: %.2f%n *Attack: %.2f%n *Defense: %.2f%n *Targets: %s%n *Aggressive Mode(%s)",
                this.getHealthPoints(),
                this.getAttackPoints(),
                this.getDefensePoints(),
                sb.toString(),
                mode)+
                System.lineSeparator();
    }
}
