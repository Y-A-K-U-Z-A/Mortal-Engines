package entities;

import entities.interfaces.Tank;

import java.util.ArrayList;

public class TankImpl extends BaseMachine implements Tank {
    private boolean defenseMode;
    private static double attackPointsModifier = 40;
    private static double defensePointsModifier = 30;
    public TankImpl(String name, double attackPoints, double defensePoints) {
        super(name, attackPoints, defensePoints, 100);
//        setAttackPoints(getAttackPoints()-attackPoints);
//        setDefensePoints(getDefensePoints() + defensePoints);
        defenseMode = false;
        toggleDefenseMode();
    }


    @Override
    public boolean getDefenseMode() {
        return defenseMode;
    }

    @Override
    public void toggleDefenseMode() {
        if (defenseMode){
            defenseMode = false;
            setAttackPoints(getAttackPoints()+attackPointsModifier);
            setDefensePoints(getDefensePoints()-defensePointsModifier);
        }else {
            defenseMode = true;
            setAttackPoints(getAttackPoints()-attackPointsModifier);
            setDefensePoints(getDefensePoints()+defensePointsModifier);
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        if (getTargets().isEmpty()){
            sb.append("None");
        }else {
            ArrayList<String> arr = new ArrayList<>(getTargets());
            for (int i = 0; i < arr.size(); i++) {
                if (i == arr.size() -1){
                    sb.append(arr.get(i));
                }else {
                    sb.append(arr.get(i)).append(", ");
                }
            }
        }
        String mode = "";

        if (getDefenseMode()){
            mode= "ON";
        }else {
            mode = "OFF";
        }
        return String.format(" *Type: Tank%n *Health: %.2f%n *Attack: %.2f%n *Defense: %.2f%n *Targets: %s%n *Defense Mode(%s)",
                this.getHealthPoints(),
                this.getAttackPoints(),
                this.getDefensePoints(),
                sb.toString(),
                mode)
                + System.lineSeparator();
    }
}
