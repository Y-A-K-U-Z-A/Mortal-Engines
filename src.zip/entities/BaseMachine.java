package entities;

import entities.interfaces.Machine;
import entities.interfaces.Pilot;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

public abstract class BaseMachine implements Machine {
    //	name – String (If the name is null or whitespace throw an IllegalArgumentException with message "Machine name cannot be null or empty.")
    //	pilot – the machine pilot (if the pilot is null throw NullPointerException with message "PilotImpl cannot be null.")
    //	attackPoints – double
    //	defensePoints - double
    //	healthPoints - double
    //	targets – collection of Strings
    private String name;
    private Pilot pilot;
    private double attackPoints;
    private double defensePoints;
    private double healthPoints;
    private Collection<String> targets;
    private boolean hasMachine;

    protected BaseMachine(String name, double attackPoints, double defensePoints, double healthPoints) {
        this.setName(name);
        this.attackPoints = attackPoints;
        this.defensePoints = defensePoints;
        this.healthPoints = healthPoints;
        targets = new ArrayList<>();
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        if (name == null || name.trim().isEmpty()){
            throw new IllegalArgumentException("Machine name cannot be null or empty.");
        }
        this.hasMachine = true;
        this.name = name;
    }

    @Override
    public Pilot getPilot() {
        return pilot;
    }

    @Override
    public void setPilot(Pilot pilot) {
        if (pilot == null){
            throw new NullPointerException("Pilot cannot be null.");
        }
        this.pilot = pilot;
    }

    @Override
    public double getHealthPoints() {
        return healthPoints;
    }

    @Override
    public void setHealthPoints(double healthPoints) {
        this.healthPoints = healthPoints;
    }

    protected void setAttackPoints(double attackPoints) {
        this.attackPoints = attackPoints;
    }

    protected void setDefensePoints(double defensePoints) {
        this.defensePoints = defensePoints;
    }

    @Override
    public double getAttackPoints() {
        return attackPoints;
    }

    @Override
    public double getDefensePoints() {
        return defensePoints;
    }

    @Override
    public List<String> getTargets() {
        return this.targets.stream().collect(Collectors.toList());
    }

    @Override
    public void attack(String target) {
        //TODO implement method
        if (target == null || target.trim().isEmpty()){
            throw new IllegalArgumentException("Attack target cannot be null or empty string.");
        }
        this.targets.add(target);
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        if (targets.isEmpty()){
            sb.append("None");
        }else {
            ArrayList<String> arr = new ArrayList<>(targets);
            for (int i = 0; i < arr.size(); i++) {
                if (i == arr.size() -1){
                    sb.append(arr.get(i));
                }else {
                    sb.append(arr.get(i)).append(", ");
                }
            }
        }
        return String.format(" *Type: %s%n *Health: %.2f%n *Attack: %.2f%n *Defense: %.2f%n *Targets: %s",
                this.getClass().getSimpleName(),
                this.healthPoints,
                this.attackPoints,
                this.defensePoints,
                sb.toString());
    }
}
